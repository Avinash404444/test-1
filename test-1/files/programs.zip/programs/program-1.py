import pandas as pd

# Create sample data
data = {
    "Name": ["Anu", "Bala", "Charan", "Divya"],
    "Age": [20, 21, 19, 22],
    "Mark": [85, 78, 92, 88]
}

df = pd.DataFrame(data)

# Save data as CSV and JSON
df.to_csv("students.csv", index=False)
df.to_json("students.json", orient="records")

# Read CSV file
csv_data = pd.read_csv("students.csv")

# Read JSON file
json_data = pd.read_json("students.json")

print("CSV Data:")
print(csv_data)

print("\nJSON Data:")
print(json_data)

print("\nCSV Dataset Shape:", csv_data.shape)

print("\nStatistical Summary:")
print(csv_data.describe())