import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
# Load dataset
df = sns.load_dataset("iris")
# Display basic information
print("Dataset Shape:", df.shape)
print("\nDataset:")
print(df.head())
print("\nStatistical Summary:")
print(df.describe())
print("\nMissing Values:")
print(df.isnull().sum())
# Species distribution
sns.countplot(x="species", data=df)
plt.title("Species Distribution")
plt.show()
# Feature comparison
sns.scatterplot(
    x="sepal_length",
    y="petal_length",
    hue="species",
    data=df
)
plt.title("Sepal Length vs Petal Length")
plt.show()
# Box plot
sns.boxplot(
    x="species",
    y="petal_length",
    data=df
)
plt.title("Petal Length Distribution")
plt.show()