import numpy as np

marks = np.array([65, 72, 80, 85, 90, 76, 88, 95, 70, 82])

print("Marks:", marks)

print("Mean:", np.mean(marks))
print("Median:", np.median(marks))
print("Variance:", np.var(marks))
print("Standard Deviation:", np.std(marks))
print("Minimum:", np.min(marks))
print("Maximum:", np.max(marks))
print("25th Percentile:", np.percentile(marks, 25))
print("75th Percentile:", np.percentile(marks, 75))