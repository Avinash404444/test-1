import matplotlib.pyplot as plt
subjects = ["Python", "DBMS", "ML", "Statistics", "Web"]
marks = [85, 78, 92, 88, 80]
plt.bar(subjects, marks)
for i, mark in enumerate(marks):
    plt.text(i, mark + 1, str(mark), ha="center")
plt.xlabel("Subjects")
plt.ylabel("Marks")
plt.title("Subject-wise Marks Comparison")
plt.ylim(0, 100)
plt.show()