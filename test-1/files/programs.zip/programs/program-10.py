import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
data = pd.DataFrame({
    "Student": ["Anu", "Bala", "Charan", "Divya", "Esha"],
    "StudyHours": [2, 3, 5, 4, 6],
    "Mark": [65, 72, 85, 80, 92]
})
# Bar plot
sns.barplot(x="Student", y="Mark", data=data)
plt.title("Student Marks")
plt.show()
# Scatter plot
sns.scatterplot(x="StudyHours", y="Mark", data=data)
plt.title("Study Hours vs Marks")
plt.show()

""" pip install seaborn """