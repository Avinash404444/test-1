import json

data = {
    "students": [
        {"id": 101, "name": "Anu", "course": "B.Sc CS", "mark": 85},
        {"id": 102, "name": "Bala", "course": "BCA DS", "mark": 90},
        {"id": 103, "name": "Charan", "course": "B.Sc CS", "mark": 78}
    ]
}

# Write JSON data to file
with open("students.json", "w") as file:
    json.dump(data, file, indent=4)

# Read JSON file
with open("students.json", "r") as file:
    student_data = json.load(file)

print("Student Details:")

for student in student_data["students"]:
    print("ID:", student["id"])
    print("Name:", student["name"])
    print("Course:", student["course"])
    print("Mark:", student["mark"])
    print()