import pandas as pd
import numpy as np

data = {
    "Name": ["Anu", "Bala", "Charan", "Divya", "Anu"],
    "Age": [20, 21, np.nan, 22, 20],
    "Mark": [85, 78, 92, np.nan, 85]
}

df = pd.DataFrame(data)

print("Original Dataset:")
print(df)

# Remove duplicates
df = df.drop_duplicates()

# Fill missing values
df["Age"] = df["Age"].fillna(df["Age"].mean())
df["Mark"] = df["Mark"].fillna(df["Mark"].mean())

# Filter students with marks above 80
filtered = df[df["Mark"] > 80]

print("\nCleaned Dataset:")
print(df)

print("\nFiltered Dataset:")
print(filtered)