import pandas as pd
students = pd.DataFrame({
    "ID": [101, 102, 103, 104],
    "Name": ["Anu", "Bala", "Charan", "Divya"]
})
marks = pd.DataFrame({
    "ID": [101, 102, 103, 104],
    "Mark": [85, 78, 92, 88]
})
merged = pd.merge(students, marks, on="ID")
print("Merged Dataset:")
print(merged)
print("\nAverage Mark:", merged["Mark"].mean())
print("\nStudents with Mark > 80:")
print(merged[merged["Mark"] > 80])
