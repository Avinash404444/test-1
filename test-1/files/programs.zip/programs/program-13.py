import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load Iris dataset
iris = sns.load_dataset("iris")

print("First Five Records:")
print(iris.head())

print("\nDataset Information:")
print(iris.info())

print("\nMissing Values:")
print(iris.isnull().sum())

print("\nStatistical Summary:")
print(iris.describe())

print("\nSpecies Count:")
print(iris["species"].value_counts())

# Pair plot
sns.pairplot(iris, hue="species")
plt.show()

# Correlation heatmap
numeric_data = iris.drop(columns=["species"])

sns.heatmap(numeric_data.corr(), annot=True)
plt.title("Correlation Heatmap")
plt.show()