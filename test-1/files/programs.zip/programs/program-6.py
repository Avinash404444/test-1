import numpy as np
import matplotlib.pyplot as plt

# Simulate 1000 dice throws
throws = np.random.randint(1, 7, 1000)

# Count occurrences
values, counts = np.unique(throws, return_counts=True)

print("Dice Distribution:")
for value, count in zip(values, counts):
    print(value, ":", count)

# Visualization
plt.bar(values, counts)
plt.xlabel("Dice Value")
plt.ylabel("Frequency")
plt.title("Dice Throw Distribution")
plt.xticks(values)
plt.show()