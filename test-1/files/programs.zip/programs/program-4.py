import numpy as np

# Create an array
arr = np.array([10, 20, 30, 40, 50])

print("Original Array:", arr)
print("First Element:", arr[0])
print("Array Slice:", arr[1:4])

# Arithmetic operation
print("Array + 5:", arr + 5)
print("Array * 2:", arr * 2)

# Two-dimensional array
matrix = np.array([[1, 2, 3], [4, 5, 6]])

print("\n2D Array:")
print(matrix)

print("\nReshaped Array:")
print(np.arange(1, 10).reshape(3, 3))