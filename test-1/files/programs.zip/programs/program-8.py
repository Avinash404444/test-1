import pandas as pd
data = {
    "Name": ["Anu", "Bala", "Charan", "Divya", "Esha", "Fathima"],
    "Department": ["CS", "CS", "DS", "DS", "CS", "DS"],
    "Mark": [85, 78, 92, 88, 90, 82]
}
df = pd.DataFrame(data)
df.to_csv("students.csv", index=False)
data = pd.read_csv("students.csv")
print("Student Data:")
print(data)
grouped = data.groupby("Department")["Mark"].mean()
print("\nAverage Mark by Department:")
print(grouped)