import streamlit as st
import pandas as pd

# Page configuration
st.set_page_config(
    page_title="Student Performance Dashboard",
    layout="wide"
)

# Dashboard title
st.title("Student Performance Dashboard")

# Create student data
data = pd.DataFrame({
    "Name": ["Anu", "Bala", "Charan", "Divya"],
    "Department": ["CS", "CS", "DS", "DS"],
    "Mark": [85, 78, 92, 88]
})

# Display all student data
st.subheader("Student Data")
st.dataframe(data, use_container_width=True)

# Department selection
department = st.selectbox(
    "Select Department",
    options=sorted(data["Department"].unique())
)

# Filter student data
filtered_data = data[data["Department"] == department]

# Display filtered data
st.subheader(f"Students in {department} Department")
st.dataframe(filtered_data, use_container_width=True)

# Display bar chart
st.subheader("Student Marks")
st.bar_chart(
    filtered_data.set_index("Name")["Mark"]
)


""" "C:\Program Files\Python313\python.exe" -m streamlit run "dir" """