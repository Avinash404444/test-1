import pandas as pd
import numpy as np
# Sample team-selected dataset
data = pd.DataFrame({
    "Name": ["Anu", "Bala", "Charan", "Divya", "Esha"],
    "Age": [20, 21, np.nan, 22, 21],
    "Mark": [85, 78, 92, np.nan, 88]
})
print("Original Dataset:")
print(data)
# Handle missing values
data["Age"] = data["Age"].fillna(data["Age"].mean())
data["Mark"] = data["Mark"].fillna(data["Mark"].mean())
# Remove duplicates
data = data.drop_duplicates()
# Save cleaned dataset
data.to_csv("cleaned_dataset.csv", index=False)
print("\nCleaned Dataset:")
print(data)