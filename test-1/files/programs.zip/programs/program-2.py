text = "Python is a powerful language for data analysis"

# Text processing
lower_text = text.lower()
words = lower_text.split()

print("Original Text:", text)
print("Lowercase Text:", lower_text)
print("Words:", words)
print("Number of Words:", len(words))

# List processing
numbers = [10, 15, 20, 25, 30, 35, 40]

even_numbers = [n for n in numbers if n % 2 == 0]

print("\nOriginal List:", numbers)
print("Even Numbers:", even_numbers)